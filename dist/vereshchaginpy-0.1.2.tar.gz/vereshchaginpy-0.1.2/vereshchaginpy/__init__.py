# VereshchaginPy
__version__ = "0.1.0"

from .vereshchagin_figures import *
from .vereshchagin_visualise import *
from .vereshchagin_core import *
from .vereshchagin_pairs import *
